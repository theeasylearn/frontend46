// without argument and without return value function
#include<stdio.h>
// define function
void printline()
{
    printf("\n-------------------------");
}

void main()
{
    // calling function
    printline();
    printf("\nhello world");
    printline();
    printline();
}