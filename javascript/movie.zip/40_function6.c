// write function for digital cloack

#include <stdio.h>
#include <windows.h>

void clock(int s,int m ,int h)
{
    int sec = 0, min = 0, hour = 0;

    while (1)
    {
        system("cls");

        printf("\n***************\n");
        printf(" %02d : %02d : %02d", sec, min, hour);
        printf("\n***************\n");

        Sleep(1000);

        sec++;
        if (sec == 61)
        {
            min++;
            sec = 1;
        }
        if (min == 60)
        {
            hour++;
            min = 0;
        }
        if (hour == 24)
        {
            hour = 0;
        }

        if(sec==s+1 && min==m && hour==h)
        {
            break;
        }
    }
}

void main()
{
    int s,m,h;
    printf("enter sec : ");
    scanf("%d",&s);

    printf("enter min : ");
    scanf("%d",&m);

    printf("enter hour : ");
    scanf("%d",&h);

    clock(s,m,h);
}